# Genomic Prediction for Powdery Mildew Resistance in Wheat — Analysis Code

Code accompanying the revised manuscript "Genomic Prediction for Powdery
Mildew Resistance in Wheat: A Thirty-Model Benchmark of Conventional,
Machine-Learning, and Deep-Learning Approaches" (WAMI panel, n=286,
20,996 SNPs, DS1–DS3).

This repository contains the analysis pipeline used to address two
issues raised in editorial review: (1) seven "Bayesian-alphabet" models
were originally implemented as regularized-regression proxies rather
than genuine Bayesian models, and (2) pooled cross-validation across
years risked genotype leakage (the same genotype's marker profile
appearing in both training and validation via a different year's
phenotype). Six of the seven Bayesian-alphabet models are now fit with
genuine BGLR implementations; BayesR remains a disclosed proxy, since
BGLR has no native BayesR routine. All thirty models are re-evaluated
under genotype-grouped (leakage-safe) cross-validation.

## Data

Not included in this repository. The genotypic (SNP marker) data for
the WAMI panel are publicly available through the CIMMYT research data
repository [ACCESSION/DOI/URL]. Phenotypic data are available from the
corresponding author upon reasonable request (see the manuscript's Data
Availability Statement).

Expected files, placed in `data/`:
- `data.txt` — phenotype file: `Taxa`, `DS1`, `DS2`, `DS3` columns, tab-separated
- `Genotype.Numerical.txt` — marker file: taxa ID + SNP columns, 0/1/2-coded, tab-separated

## Pipeline overview

Three independent sub-pipelines produce the 30-model benchmark; a final
script merges their output.

| Step | Script | Models covered | What it produces |
|---|---|---|---|
| 0 | `R/00_smoke_test.R` | — | Confirms BGLR installs/runs correctly before the full run |
| 1 | `R/01_bglr_fold.R` | — | Core function library (`run_bglr_fold()`), sourced by the scripts below |
| 2 | `R/02_bglr_per_year_and_pooled_ordinary.R` | BayesA, BayesB, BayesC, BayesCπ, BRR, BL | Per-year results (Table S4) + pooled results under ordinary/ungrouped CV (feeds the leakage-delta comparison) |
| 3 | `R/03_bglr_pooled_grouped.R` | same 6 | Pooled results under genotype-grouped (leakage-safe) CV — feeds Table 4 |
| 4 | `python/01_benchmark_13_conventional_ml.py` | GBLUP, rrBLUP, RKHS, RandomForest, GBM, SVR, KNN, DecisionTree, ElasticNet, PLS, KRR, XGBoost, LightGBM | Per-year + pooled (both CV schemes) |
| 5 | `python/02_benchmark_10_deep_learning.py` | DNN, MLP, CNN, DualCNN, ResNet, RNN, LSTM, GRU, Transformer, Autoencoder | Per-year + pooled (both CV schemes) |
| 6 | `python/03_merge_and_build_table4.py` | all 29 (+ BayesR proxy, added manually) | Final `table4_grouped_final.csv` and `table_S5b_leakage_delta.csv` |
| 7 | `R/figure3_per_year_accuracy.R` | all 30 | Regenerates manuscript Figure 3 |

BayesR is never computed by any script here — see the header comment in
`python/03_merge_and_build_table4.py` for how it's handled (kept as a
disclosed proxy, not fabricated).

## Requirements

**R** (tested with BGLR via CRAN):
```r
install.packages(c("BGLR", "ggplot2", "patchwork"))
```

**Python:**
```bash
pip install scikit-learn pandas numpy scipy xgboost lightgbm tensorflow
```

## Running the full pipeline

```bash
# 1. Confirm BGLR works
Rscript R/00_smoke_test.R

# 2. Genuine BGLR: per-year + pooled ordinary CV (long-running: ~240 MCMC fits)
Rscript R/02_bglr_per_year_and_pooled_ordinary.R

# 3. Genuine BGLR: pooled grouped/leakage-safe CV (long-running: ~150 MCMC fits,
#    resumable if interrupted)
Rscript R/03_bglr_pooled_grouped.R

# 4. The other 24 models, both CV schemes
python3 python/01_benchmark_13_conventional_ml.py
python3 python/02_benchmark_10_deep_learning.py

# 5. Merge everything into the final Table 4 / Table S5b
python3 python/03_merge_and_build_table4.py

# 6. Regenerate Figure 3 (paste directly into R/RStudio, or:)
Rscript R/figure3_per_year_accuracy.R
```

All scripts write their output to `./output/` by default (edit the
`OUT_DIR`/`CONFIG` block at the top of each script to change this).

## Notes on runtime

BGLR does real MCMC sampling per fold (`nIter=12000`, `burnIn=2000` by
default) — steps 2–3 together are on the order of hours, not minutes,
depending on your machine. Both R scripts save progress incrementally
and can be safely re-run after an interruption (`03_bglr_pooled_grouped.R`
has built-in resume logic; for step 2, split it by trait/scheme if you
need to checkpoint more granularly).

## Known limitations, disclosed in the manuscript

- **BayesR** has no native BGLR implementation and remains a disclosed
  regularized-regression proxy throughout.
- **Leave-one-year-out cross-validation** (manuscript Table S6) and the
  **six-model paired-permutation comparison** (Table S7) were not
  re-run with the genuine BGLR models in this revision cycle; their
  Bayesian-alphabet rows still reflect the original proxy
  implementation. This is explicitly disclosed in the corresponding
  Supplementary Table notes.
- **Computational timing** (Table S2) for the genuine BGLR models was
  not captured during these runs and is not reflected in that table.

## License / citation

[Add license and citation information before publishing this repository.]
